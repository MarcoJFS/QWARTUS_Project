<?php

namespace api\modules\v1\controllers;

use yii\rest\ActiveController;

class DistritoController extends ActiveController
{
    public $modelClass = 'frontend\models\Distritos';
}