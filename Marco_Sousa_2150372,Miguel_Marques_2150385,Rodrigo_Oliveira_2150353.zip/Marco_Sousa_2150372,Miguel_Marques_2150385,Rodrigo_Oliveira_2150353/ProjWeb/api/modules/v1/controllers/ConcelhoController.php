<?php

namespace api\modules\v1\controllers;

use yii\rest\ActiveController;

class ConcelhoController extends ActiveController
{
    public $modelClass = 'frontend\models\Concelhos';
}