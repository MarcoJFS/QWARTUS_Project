<?php

	namespace app\models;

	use yii\db\ActiveRecord;

	class Concelhos extends ActiveRecord
	{

		

	}

?>