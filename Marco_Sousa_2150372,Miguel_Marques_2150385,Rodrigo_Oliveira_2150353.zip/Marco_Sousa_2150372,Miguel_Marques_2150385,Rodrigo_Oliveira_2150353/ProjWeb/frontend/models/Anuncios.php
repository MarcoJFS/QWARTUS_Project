<?php

	namespace app\models;

	use yii\db\ActiveRecord;

	class Anuncios extends ActiveRecord
	{

		

	}

?>