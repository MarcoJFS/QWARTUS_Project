﻿namespace RestApi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.anuncios = new System.Windows.Forms.TabPage();
            this.btn_todos_anuncios = new System.Windows.Forms.Button();
            this.btn_ver_anuncios = new System.Windows.Forms.Button();
            this.btn_eliminar_anuncios = new System.Windows.Forms.Button();
            this.btn_alterar_anuncios = new System.Windows.Forms.Button();
            this.btn_adicionar_anuncios = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_id_concelho = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_id_distrito = new System.Windows.Forms.TextBox();
            this.tb_descricao = new System.Windows.Forms.TextBox();
            this.tb_preco = new System.Windows.Forms.TextBox();
            this.tb_asunto = new System.Windows.Forms.TextBox();
            this.tb_ce_id_registado = new System.Windows.Forms.TextBox();
            this.tb_id_anuncio = new System.Windows.Forms.TextBox();
            this.users = new System.Windows.Forms.TabPage();
            this.btn_todos_users = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_ver_users = new System.Windows.Forms.Button();
            this.btn_eliminar_users = new System.Windows.Forms.Button();
            this.btn_alterar_users = new System.Windows.Forms.Button();
            this.tb_contacto = new System.Windows.Forms.TextBox();
            this.tb_ultimo_nome = new System.Windows.Forms.TextBox();
            this.tb_primeiro_nome = new System.Windows.Forms.TextBox();
            this.tb_updated_at = new System.Windows.Forms.TextBox();
            this.tb_created_at = new System.Windows.Forms.TextBox();
            this.tb_status = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.tb_password_reset_token = new System.Windows.Forms.TextBox();
            this.tb_password_hash = new System.Windows.Forms.TextBox();
            this.tb_auth_key = new System.Windows.Forms.TextBox();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.distritos = new System.Windows.Forms.TabPage();
            this.btn_todos_distritos = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tb_nome_distritos = new System.Windows.Forms.TextBox();
            this.tb_id_distritos = new System.Windows.Forms.TextBox();
            this.btn_ver_distritos = new System.Windows.Forms.Button();
            this.btn_eliminar_distritos = new System.Windows.Forms.Button();
            this.btn_alterar_distritos = new System.Windows.Forms.Button();
            this.btn_adicionar_distritos = new System.Windows.Forms.Button();
            this.tb_password_login = new System.Windows.Forms.TextBox();
            this.tb_username_login = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_registar = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.tb_password_registar = new System.Windows.Forms.TextBox();
            this.tb_email_registar = new System.Windows.Forms.TextBox();
            this.tb_username_registar = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lb_todos_distritos = new System.Windows.Forms.ListBox();
            this.lb_todos_anuncios = new System.Windows.Forms.ListBox();
            this.lb_todos_user = new System.Windows.Forms.ListBox();
            this.tabControl.SuspendLayout();
            this.anuncios.SuspendLayout();
            this.users.SuspendLayout();
            this.distritos.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.anuncios);
            this.tabControl.Controls.Add(this.users);
            this.tabControl.Controls.Add(this.distritos);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(564, 384);
            this.tabControl.TabIndex = 3;
            // 
            // anuncios
            // 
            this.anuncios.Controls.Add(this.lb_todos_anuncios);
            this.anuncios.Controls.Add(this.btn_todos_anuncios);
            this.anuncios.Controls.Add(this.btn_ver_anuncios);
            this.anuncios.Controls.Add(this.btn_eliminar_anuncios);
            this.anuncios.Controls.Add(this.btn_alterar_anuncios);
            this.anuncios.Controls.Add(this.btn_adicionar_anuncios);
            this.anuncios.Controls.Add(this.label7);
            this.anuncios.Controls.Add(this.label6);
            this.anuncios.Controls.Add(this.label5);
            this.anuncios.Controls.Add(this.label4);
            this.anuncios.Controls.Add(this.label3);
            this.anuncios.Controls.Add(this.tb_id_concelho);
            this.anuncios.Controls.Add(this.label2);
            this.anuncios.Controls.Add(this.label1);
            this.anuncios.Controls.Add(this.tb_id_distrito);
            this.anuncios.Controls.Add(this.tb_descricao);
            this.anuncios.Controls.Add(this.tb_preco);
            this.anuncios.Controls.Add(this.tb_asunto);
            this.anuncios.Controls.Add(this.tb_ce_id_registado);
            this.anuncios.Controls.Add(this.tb_id_anuncio);
            this.anuncios.Location = new System.Drawing.Point(4, 22);
            this.anuncios.Name = "anuncios";
            this.anuncios.Padding = new System.Windows.Forms.Padding(3);
            this.anuncios.Size = new System.Drawing.Size(556, 358);
            this.anuncios.TabIndex = 0;
            this.anuncios.Text = "Anuncios";
            this.anuncios.UseVisualStyleBackColor = true;
            // 
            // btn_todos_anuncios
            // 
            this.btn_todos_anuncios.Location = new System.Drawing.Point(350, 329);
            this.btn_todos_anuncios.Name = "btn_todos_anuncios";
            this.btn_todos_anuncios.Size = new System.Drawing.Size(200, 23);
            this.btn_todos_anuncios.TabIndex = 32;
            this.btn_todos_anuncios.Text = "Ver Todos";
            this.btn_todos_anuncios.UseVisualStyleBackColor = true;
            this.btn_todos_anuncios.Click += new System.EventHandler(this.btn_todos_anuncios_Click);
            // 
            // btn_ver_anuncios
            // 
            this.btn_ver_anuncios.Location = new System.Drawing.Point(251, 329);
            this.btn_ver_anuncios.Name = "btn_ver_anuncios";
            this.btn_ver_anuncios.Size = new System.Drawing.Size(75, 23);
            this.btn_ver_anuncios.TabIndex = 17;
            this.btn_ver_anuncios.Text = "Ver";
            this.btn_ver_anuncios.UseVisualStyleBackColor = true;
            this.btn_ver_anuncios.Click += new System.EventHandler(this.btn_ver_Click);
            // 
            // btn_eliminar_anuncios
            // 
            this.btn_eliminar_anuncios.Location = new System.Drawing.Point(170, 329);
            this.btn_eliminar_anuncios.Name = "btn_eliminar_anuncios";
            this.btn_eliminar_anuncios.Size = new System.Drawing.Size(75, 23);
            this.btn_eliminar_anuncios.TabIndex = 16;
            this.btn_eliminar_anuncios.Text = "Eliminar";
            this.btn_eliminar_anuncios.UseVisualStyleBackColor = true;
            this.btn_eliminar_anuncios.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // btn_alterar_anuncios
            // 
            this.btn_alterar_anuncios.Location = new System.Drawing.Point(84, 329);
            this.btn_alterar_anuncios.Name = "btn_alterar_anuncios";
            this.btn_alterar_anuncios.Size = new System.Drawing.Size(75, 23);
            this.btn_alterar_anuncios.TabIndex = 15;
            this.btn_alterar_anuncios.Text = "Alterar";
            this.btn_alterar_anuncios.UseVisualStyleBackColor = true;
            this.btn_alterar_anuncios.Click += new System.EventHandler(this.btn_alterar_Click);
            // 
            // btn_adicionar_anuncios
            // 
            this.btn_adicionar_anuncios.Location = new System.Drawing.Point(3, 329);
            this.btn_adicionar_anuncios.Name = "btn_adicionar_anuncios";
            this.btn_adicionar_anuncios.Size = new System.Drawing.Size(75, 23);
            this.btn_adicionar_anuncios.TabIndex = 14;
            this.btn_adicionar_anuncios.Text = "Adicionar";
            this.btn_adicionar_anuncios.UseVisualStyleBackColor = true;
            this.btn_adicionar_anuncios.Click += new System.EventHandler(this.btn_adicionar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 306);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "id_concelho:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(64, 277);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "id_distrito:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(58, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "id_anuncio:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(83, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "preco:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "asunto:";
            // 
            // tb_id_concelho
            // 
            this.tb_id_concelho.Location = new System.Drawing.Point(126, 303);
            this.tb_id_concelho.Name = "tb_id_concelho";
            this.tb_id_concelho.Size = new System.Drawing.Size(200, 20);
            this.tb_id_concelho.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "descricao:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "ce_id_user:";
            // 
            // tb_id_distrito
            // 
            this.tb_id_distrito.Location = new System.Drawing.Point(126, 277);
            this.tb_id_distrito.Name = "tb_id_distrito";
            this.tb_id_distrito.Size = new System.Drawing.Size(200, 20);
            this.tb_id_distrito.TabIndex = 5;
            // 
            // tb_descricao
            // 
            this.tb_descricao.Location = new System.Drawing.Point(126, 112);
            this.tb_descricao.Multiline = true;
            this.tb_descricao.Name = "tb_descricao";
            this.tb_descricao.Size = new System.Drawing.Size(200, 159);
            this.tb_descricao.TabIndex = 4;
            // 
            // tb_preco
            // 
            this.tb_preco.Location = new System.Drawing.Point(126, 86);
            this.tb_preco.Name = "tb_preco";
            this.tb_preco.Size = new System.Drawing.Size(200, 20);
            this.tb_preco.TabIndex = 3;
            // 
            // tb_asunto
            // 
            this.tb_asunto.Location = new System.Drawing.Point(126, 60);
            this.tb_asunto.Name = "tb_asunto";
            this.tb_asunto.Size = new System.Drawing.Size(200, 20);
            this.tb_asunto.TabIndex = 2;
            // 
            // tb_ce_id_registado
            // 
            this.tb_ce_id_registado.Location = new System.Drawing.Point(126, 34);
            this.tb_ce_id_registado.Name = "tb_ce_id_registado";
            this.tb_ce_id_registado.Size = new System.Drawing.Size(200, 20);
            this.tb_ce_id_registado.TabIndex = 1;
            // 
            // tb_id_anuncio
            // 
            this.tb_id_anuncio.Location = new System.Drawing.Point(126, 8);
            this.tb_id_anuncio.Name = "tb_id_anuncio";
            this.tb_id_anuncio.Size = new System.Drawing.Size(200, 20);
            this.tb_id_anuncio.TabIndex = 0;
            // 
            // users
            // 
            this.users.Controls.Add(this.lb_todos_user);
            this.users.Controls.Add(this.btn_todos_users);
            this.users.Controls.Add(this.label19);
            this.users.Controls.Add(this.label18);
            this.users.Controls.Add(this.label17);
            this.users.Controls.Add(this.label16);
            this.users.Controls.Add(this.label15);
            this.users.Controls.Add(this.label14);
            this.users.Controls.Add(this.label13);
            this.users.Controls.Add(this.label12);
            this.users.Controls.Add(this.label11);
            this.users.Controls.Add(this.label10);
            this.users.Controls.Add(this.label9);
            this.users.Controls.Add(this.label8);
            this.users.Controls.Add(this.btn_ver_users);
            this.users.Controls.Add(this.btn_eliminar_users);
            this.users.Controls.Add(this.btn_alterar_users);
            this.users.Controls.Add(this.tb_contacto);
            this.users.Controls.Add(this.tb_ultimo_nome);
            this.users.Controls.Add(this.tb_primeiro_nome);
            this.users.Controls.Add(this.tb_updated_at);
            this.users.Controls.Add(this.tb_created_at);
            this.users.Controls.Add(this.tb_status);
            this.users.Controls.Add(this.tb_email);
            this.users.Controls.Add(this.tb_password_reset_token);
            this.users.Controls.Add(this.tb_password_hash);
            this.users.Controls.Add(this.tb_auth_key);
            this.users.Controls.Add(this.tb_username);
            this.users.Controls.Add(this.tb_id);
            this.users.Location = new System.Drawing.Point(4, 22);
            this.users.Name = "users";
            this.users.Padding = new System.Windows.Forms.Padding(3);
            this.users.Size = new System.Drawing.Size(556, 358);
            this.users.TabIndex = 1;
            this.users.Text = "Users";
            this.users.UseVisualStyleBackColor = true;
            // 
            // btn_todos_users
            // 
            this.btn_todos_users.Location = new System.Drawing.Point(350, 329);
            this.btn_todos_users.Name = "btn_todos_users";
            this.btn_todos_users.Size = new System.Drawing.Size(200, 23);
            this.btn_todos_users.TabIndex = 32;
            this.btn_todos_users.Text = "Ver Todos";
            this.btn_todos_users.UseVisualStyleBackColor = true;
            this.btn_todos_users.Click += new System.EventHandler(this.btn_todos_users_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(68, 292);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 13);
            this.label19.TabIndex = 30;
            this.label19.Text = "contacto:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(51, 266);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 13);
            this.label18.TabIndex = 29;
            this.label18.Text = "ultimo_nome:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(42, 240);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "primeiro_nome:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(56, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 23;
            this.label16.Text = "updated_at:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(62, 191);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 13);
            this.label15.TabIndex = 23;
            this.label15.Text = "created_at:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(85, 165);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 13);
            this.label14.TabIndex = 27;
            this.label14.Text = "status:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(89, 136);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "email:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 113);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(117, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "password_reset_token:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(39, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "password_hash:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(69, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "auth_key";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(64, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "username:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(102, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "id:";
            // 
            // btn_ver_users
            // 
            this.btn_ver_users.Location = new System.Drawing.Point(251, 329);
            this.btn_ver_users.Name = "btn_ver_users";
            this.btn_ver_users.Size = new System.Drawing.Size(75, 23);
            this.btn_ver_users.TabIndex = 21;
            this.btn_ver_users.Text = "Ver";
            this.btn_ver_users.UseVisualStyleBackColor = true;
            this.btn_ver_users.Click += new System.EventHandler(this.btn_ver_users_Click);
            // 
            // btn_eliminar_users
            // 
            this.btn_eliminar_users.Location = new System.Drawing.Point(170, 329);
            this.btn_eliminar_users.Name = "btn_eliminar_users";
            this.btn_eliminar_users.Size = new System.Drawing.Size(75, 23);
            this.btn_eliminar_users.TabIndex = 20;
            this.btn_eliminar_users.Text = "Eliminar";
            this.btn_eliminar_users.UseVisualStyleBackColor = true;
            this.btn_eliminar_users.Click += new System.EventHandler(this.btn_eliminar_users_Click);
            // 
            // btn_alterar_users
            // 
            this.btn_alterar_users.Location = new System.Drawing.Point(84, 329);
            this.btn_alterar_users.Name = "btn_alterar_users";
            this.btn_alterar_users.Size = new System.Drawing.Size(75, 23);
            this.btn_alterar_users.TabIndex = 19;
            this.btn_alterar_users.Text = "Alterar";
            this.btn_alterar_users.UseVisualStyleBackColor = true;
            this.btn_alterar_users.Click += new System.EventHandler(this.btn_alterar_users_Click);
            // 
            // tb_contacto
            // 
            this.tb_contacto.Location = new System.Drawing.Point(126, 292);
            this.tb_contacto.Name = "tb_contacto";
            this.tb_contacto.Size = new System.Drawing.Size(200, 20);
            this.tb_contacto.TabIndex = 17;
            // 
            // tb_ultimo_nome
            // 
            this.tb_ultimo_nome.Location = new System.Drawing.Point(126, 266);
            this.tb_ultimo_nome.Name = "tb_ultimo_nome";
            this.tb_ultimo_nome.Size = new System.Drawing.Size(200, 20);
            this.tb_ultimo_nome.TabIndex = 16;
            // 
            // tb_primeiro_nome
            // 
            this.tb_primeiro_nome.Location = new System.Drawing.Point(126, 240);
            this.tb_primeiro_nome.Name = "tb_primeiro_nome";
            this.tb_primeiro_nome.Size = new System.Drawing.Size(200, 20);
            this.tb_primeiro_nome.TabIndex = 15;
            // 
            // tb_updated_at
            // 
            this.tb_updated_at.Enabled = false;
            this.tb_updated_at.Location = new System.Drawing.Point(126, 214);
            this.tb_updated_at.Name = "tb_updated_at";
            this.tb_updated_at.Size = new System.Drawing.Size(200, 20);
            this.tb_updated_at.TabIndex = 14;
            // 
            // tb_created_at
            // 
            this.tb_created_at.Enabled = false;
            this.tb_created_at.Location = new System.Drawing.Point(126, 188);
            this.tb_created_at.Name = "tb_created_at";
            this.tb_created_at.Size = new System.Drawing.Size(200, 20);
            this.tb_created_at.TabIndex = 13;
            // 
            // tb_status
            // 
            this.tb_status.Enabled = false;
            this.tb_status.Location = new System.Drawing.Point(126, 162);
            this.tb_status.Name = "tb_status";
            this.tb_status.Size = new System.Drawing.Size(200, 20);
            this.tb_status.TabIndex = 12;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(126, 136);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(200, 20);
            this.tb_email.TabIndex = 11;
            // 
            // tb_password_reset_token
            // 
            this.tb_password_reset_token.Enabled = false;
            this.tb_password_reset_token.Location = new System.Drawing.Point(126, 110);
            this.tb_password_reset_token.Name = "tb_password_reset_token";
            this.tb_password_reset_token.Size = new System.Drawing.Size(200, 20);
            this.tb_password_reset_token.TabIndex = 10;
            // 
            // tb_password_hash
            // 
            this.tb_password_hash.Enabled = false;
            this.tb_password_hash.Location = new System.Drawing.Point(126, 84);
            this.tb_password_hash.Name = "tb_password_hash";
            this.tb_password_hash.Size = new System.Drawing.Size(200, 20);
            this.tb_password_hash.TabIndex = 9;
            // 
            // tb_auth_key
            // 
            this.tb_auth_key.Enabled = false;
            this.tb_auth_key.Location = new System.Drawing.Point(126, 58);
            this.tb_auth_key.Name = "tb_auth_key";
            this.tb_auth_key.Size = new System.Drawing.Size(200, 20);
            this.tb_auth_key.TabIndex = 8;
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(126, 32);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(200, 20);
            this.tb_username.TabIndex = 7;
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(126, 9);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(200, 20);
            this.tb_id.TabIndex = 6;
            // 
            // distritos
            // 
            this.distritos.Controls.Add(this.lb_todos_distritos);
            this.distritos.Controls.Add(this.btn_todos_distritos);
            this.distritos.Controls.Add(this.label21);
            this.distritos.Controls.Add(this.label20);
            this.distritos.Controls.Add(this.tb_nome_distritos);
            this.distritos.Controls.Add(this.tb_id_distritos);
            this.distritos.Controls.Add(this.btn_ver_distritos);
            this.distritos.Controls.Add(this.btn_eliminar_distritos);
            this.distritos.Controls.Add(this.btn_alterar_distritos);
            this.distritos.Controls.Add(this.btn_adicionar_distritos);
            this.distritos.Location = new System.Drawing.Point(4, 22);
            this.distritos.Name = "distritos";
            this.distritos.Padding = new System.Windows.Forms.Padding(3);
            this.distritos.Size = new System.Drawing.Size(556, 358);
            this.distritos.TabIndex = 2;
            this.distritos.Text = "Distritos";
            this.distritos.UseVisualStyleBackColor = true;
            // 
            // btn_todos_distritos
            // 
            this.btn_todos_distritos.Location = new System.Drawing.Point(350, 329);
            this.btn_todos_distritos.Name = "btn_todos_distritos";
            this.btn_todos_distritos.Size = new System.Drawing.Size(200, 23);
            this.btn_todos_distritos.TabIndex = 31;
            this.btn_todos_distritos.Text = "Ver Todos";
            this.btn_todos_distritos.UseVisualStyleBackColor = true;
            this.btn_todos_distritos.Click += new System.EventHandler(this.btn_todos_distritos_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(43, 39);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 13);
            this.label21.TabIndex = 29;
            this.label21.Text = "nome_distritos:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(61, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 13);
            this.label20.TabIndex = 28;
            this.label20.Text = "id_distritos:";
            // 
            // tb_nome_distritos
            // 
            this.tb_nome_distritos.Location = new System.Drawing.Point(126, 32);
            this.tb_nome_distritos.Name = "tb_nome_distritos";
            this.tb_nome_distritos.Size = new System.Drawing.Size(200, 20);
            this.tb_nome_distritos.TabIndex = 27;
            // 
            // tb_id_distritos
            // 
            this.tb_id_distritos.Location = new System.Drawing.Point(126, 9);
            this.tb_id_distritos.Name = "tb_id_distritos";
            this.tb_id_distritos.Size = new System.Drawing.Size(200, 20);
            this.tb_id_distritos.TabIndex = 26;
            // 
            // btn_ver_distritos
            // 
            this.btn_ver_distritos.Location = new System.Drawing.Point(251, 329);
            this.btn_ver_distritos.Name = "btn_ver_distritos";
            this.btn_ver_distritos.Size = new System.Drawing.Size(75, 23);
            this.btn_ver_distritos.TabIndex = 25;
            this.btn_ver_distritos.Text = "Ver";
            this.btn_ver_distritos.UseVisualStyleBackColor = true;
            this.btn_ver_distritos.Click += new System.EventHandler(this.btn_ver_distritos_Click);
            // 
            // btn_eliminar_distritos
            // 
            this.btn_eliminar_distritos.Location = new System.Drawing.Point(170, 329);
            this.btn_eliminar_distritos.Name = "btn_eliminar_distritos";
            this.btn_eliminar_distritos.Size = new System.Drawing.Size(75, 23);
            this.btn_eliminar_distritos.TabIndex = 24;
            this.btn_eliminar_distritos.Text = "Eliminar";
            this.btn_eliminar_distritos.UseVisualStyleBackColor = true;
            this.btn_eliminar_distritos.Click += new System.EventHandler(this.btn_eliminar_distritos_Click);
            // 
            // btn_alterar_distritos
            // 
            this.btn_alterar_distritos.Location = new System.Drawing.Point(84, 329);
            this.btn_alterar_distritos.Name = "btn_alterar_distritos";
            this.btn_alterar_distritos.Size = new System.Drawing.Size(75, 23);
            this.btn_alterar_distritos.TabIndex = 23;
            this.btn_alterar_distritos.Text = "Alterar";
            this.btn_alterar_distritos.UseVisualStyleBackColor = true;
            this.btn_alterar_distritos.Click += new System.EventHandler(this.btn_alterar_distritos_Click);
            // 
            // btn_adicionar_distritos
            // 
            this.btn_adicionar_distritos.Location = new System.Drawing.Point(3, 329);
            this.btn_adicionar_distritos.Name = "btn_adicionar_distritos";
            this.btn_adicionar_distritos.Size = new System.Drawing.Size(75, 23);
            this.btn_adicionar_distritos.TabIndex = 22;
            this.btn_adicionar_distritos.Text = "Adicionar";
            this.btn_adicionar_distritos.UseVisualStyleBackColor = true;
            this.btn_adicionar_distritos.Click += new System.EventHandler(this.btn_adicionar_distritos_Click);
            // 
            // tb_password_login
            // 
            this.tb_password_login.Location = new System.Drawing.Point(587, 94);
            this.tb_password_login.Name = "tb_password_login";
            this.tb_password_login.Size = new System.Drawing.Size(142, 20);
            this.tb_password_login.TabIndex = 28;
            // 
            // tb_username_login
            // 
            this.tb_username_login.Location = new System.Drawing.Point(587, 50);
            this.tb_username_login.Name = "tb_username_login";
            this.tb_username_login.Size = new System.Drawing.Size(142, 20);
            this.tb_username_login.TabIndex = 27;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(582, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 25);
            this.label23.TabIndex = 29;
            this.label23.Text = "Login";
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(587, 120);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(142, 29);
            this.btn_login.TabIndex = 30;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_registar
            // 
            this.btn_registar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registar.Location = new System.Drawing.Point(587, 357);
            this.btn_registar.Name = "btn_registar";
            this.btn_registar.Size = new System.Drawing.Size(142, 29);
            this.btn_registar.TabIndex = 34;
            this.btn_registar.Text = "Registar";
            this.btn_registar.UseVisualStyleBackColor = true;
            this.btn_registar.Click += new System.EventHandler(this.btn_registar_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(582, 211);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(100, 25);
            this.label24.TabIndex = 33;
            this.label24.Text = "Registar";
            // 
            // tb_password_registar
            // 
            this.tb_password_registar.Location = new System.Drawing.Point(587, 331);
            this.tb_password_registar.Name = "tb_password_registar";
            this.tb_password_registar.Size = new System.Drawing.Size(142, 20);
            this.tb_password_registar.TabIndex = 32;
            // 
            // tb_email_registar
            // 
            this.tb_email_registar.Location = new System.Drawing.Point(587, 291);
            this.tb_email_registar.Name = "tb_email_registar";
            this.tb_email_registar.Size = new System.Drawing.Size(142, 20);
            this.tb_email_registar.TabIndex = 31;
            // 
            // tb_username_registar
            // 
            this.tb_username_registar.Location = new System.Drawing.Point(587, 252);
            this.tb_username_registar.Name = "tb_username_registar";
            this.tb_username_registar.Size = new System.Drawing.Size(142, 20);
            this.tb_username_registar.TabIndex = 35;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(584, 314);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 13);
            this.label22.TabIndex = 33;
            this.label22.Text = "Password";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(584, 275);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(32, 13);
            this.label25.TabIndex = 36;
            this.label25.Text = "Email";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(584, 236);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(55, 13);
            this.label26.TabIndex = 37;
            this.label26.Text = "Username";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(584, 34);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 13);
            this.label27.TabIndex = 38;
            this.label27.Text = "Username";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(584, 75);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 13);
            this.label28.TabIndex = 39;
            this.label28.Text = "Password";
            // 
            // lb_todos_distritos
            // 
            this.lb_todos_distritos.FormattingEnabled = true;
            this.lb_todos_distritos.Location = new System.Drawing.Point(350, 9);
            this.lb_todos_distritos.Name = "lb_todos_distritos";
            this.lb_todos_distritos.Size = new System.Drawing.Size(200, 316);
            this.lb_todos_distritos.TabIndex = 32;
            this.lb_todos_distritos.SelectedIndexChanged += new System.EventHandler(this.lb_todos_distritos_SelectedIndexChanged);
            // 
            // lb_todos_anuncios
            // 
            this.lb_todos_anuncios.FormattingEnabled = true;
            this.lb_todos_anuncios.Location = new System.Drawing.Point(350, 6);
            this.lb_todos_anuncios.Name = "lb_todos_anuncios";
            this.lb_todos_anuncios.Size = new System.Drawing.Size(200, 316);
            this.lb_todos_anuncios.TabIndex = 33;
            this.lb_todos_anuncios.SelectedIndexChanged += new System.EventHandler(this.lb_todos_anuncios_SelectedIndexChanged);
            // 
            // lb_todos_user
            // 
            this.lb_todos_user.FormattingEnabled = true;
            this.lb_todos_user.Location = new System.Drawing.Point(350, 9);
            this.lb_todos_user.Name = "lb_todos_user";
            this.lb_todos_user.Size = new System.Drawing.Size(200, 316);
            this.lb_todos_user.TabIndex = 34;
            this.lb_todos_user.SelectedIndexChanged += new System.EventHandler(this.lb_todos_user_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 405);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.tb_username_registar);
            this.Controls.Add(this.btn_registar);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.tb_password_registar);
            this.Controls.Add(this.tb_email_registar);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.tb_password_login);
            this.Controls.Add(this.tb_username_login);
            this.Controls.Add(this.tabControl);
            this.Name = "Form1";
            this.Text = "RespApi";
            this.tabControl.ResumeLayout(false);
            this.anuncios.ResumeLayout(false);
            this.anuncios.PerformLayout();
            this.users.ResumeLayout(false);
            this.users.PerformLayout();
            this.distritos.ResumeLayout(false);
            this.distritos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage anuncios;
        private System.Windows.Forms.Button btn_ver_anuncios;
        private System.Windows.Forms.Button btn_eliminar_anuncios;
        private System.Windows.Forms.Button btn_alterar_anuncios;
        private System.Windows.Forms.Button btn_adicionar_anuncios;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_id_concelho;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_id_distrito;
        private System.Windows.Forms.TextBox tb_descricao;
        private System.Windows.Forms.TextBox tb_preco;
        private System.Windows.Forms.TextBox tb_asunto;
        private System.Windows.Forms.TextBox tb_ce_id_registado;
        private System.Windows.Forms.TextBox tb_id_anuncio;
        private System.Windows.Forms.TabPage users;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_ver_users;
        private System.Windows.Forms.Button btn_eliminar_users;
        private System.Windows.Forms.Button btn_alterar_users;
        private System.Windows.Forms.TextBox tb_contacto;
        private System.Windows.Forms.TextBox tb_ultimo_nome;
        private System.Windows.Forms.TextBox tb_primeiro_nome;
        private System.Windows.Forms.TextBox tb_updated_at;
        private System.Windows.Forms.TextBox tb_created_at;
        private System.Windows.Forms.TextBox tb_status;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.TextBox tb_password_reset_token;
        private System.Windows.Forms.TextBox tb_password_hash;
        private System.Windows.Forms.TextBox tb_auth_key;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.TabPage distritos;
        private System.Windows.Forms.Button btn_ver_distritos;
        private System.Windows.Forms.Button btn_eliminar_distritos;
        private System.Windows.Forms.Button btn_alterar_distritos;
        private System.Windows.Forms.Button btn_adicionar_distritos;
        private System.Windows.Forms.TextBox tb_password_login;
        private System.Windows.Forms.TextBox tb_username_login;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_registar;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tb_password_registar;
        private System.Windows.Forms.TextBox tb_email_registar;
        private System.Windows.Forms.TextBox tb_username_registar;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tb_nome_distritos;
        private System.Windows.Forms.TextBox tb_id_distritos;
        private System.Windows.Forms.Button btn_todos_anuncios;
        private System.Windows.Forms.Button btn_todos_users;
        private System.Windows.Forms.Button btn_todos_distritos;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ListBox lb_todos_distritos;
        private System.Windows.Forms.ListBox lb_todos_anuncios;
        private System.Windows.Forms.ListBox lb_todos_user;
    }
}

