﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestApi
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        
        }

        Tok LogToken;

        private void btn_ver_Click(object sender, EventArgs e)
        {
            if(tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/anuncios/" + tb_id_anuncio.Text);
                var request = new RestRequest();
                request.Method = Method.GET;
                request.AddHeader("Accept", "application/json");
                var response = client.Execute(request);
                var content = response.Content; //raw content as string 

                Dictionary<string, string> resp = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);
                tb_ce_id_registado.Text = resp["ce_id_registado"];
                tb_asunto.Text = resp["asunto"];
                tb_preco.Text = resp["preco"];
                tb_descricao.Text = resp["descricao"];
                tb_id_distrito.Text = resp["id_distrito"];
                tb_id_concelho.Text = resp["id_concelho"];
            }
            
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/anuncios/" + tb_id_anuncio.Text);
                var request = new RestRequest();
                request.Method = Method.DELETE;
                request.AddHeader("Accept", "application/json");
                client.Execute(request);

                tb_ce_id_registado.Text = "";
                tb_asunto.Text = "";
                tb_preco.Text = "";
                tb_descricao.Text = "";
                tb_id_distrito.Text = "";
                tb_id_concelho.Text = "";
            }
               
        }

        private void btn_alterar_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/anuncios/" + tb_id_anuncio.Text);
                var request = new RestRequest();
                request.Method = Method.PUT;
                request.AddHeader("Accept", "application/json");
                request.Parameters.Clear();
                request.AddJsonBody(
                 new
                 {
                     ce_id_registado = tb_ce_id_registado.Text,
                     asunto = tb_asunto.Text,
                     preco = tb_preco.Text,
                     descricao = tb_descricao.Text,
                     id_distrito = tb_id_distrito.Text,
                     id_concelho = tb_id_concelho.Text
                 }
                );

                client.Execute(request);
            }
                
        }

        private void btn_adicionar_Click(object sender, EventArgs e)
        {
            if(tb_ce_id_registado.Text != "" && tb_asunto.Text != "" && tb_preco.Text != "" && tb_descricao.Text != "" && tb_id_distrito.Text != "" && tb_id_concelho.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/anuncios");
                var request = new RestRequest();
                request.Method = Method.POST;
                request.AddHeader("Accept", "application/json");
                request.Parameters.Clear();
                request.AddJsonBody(
                 new
                 {
                     ce_id_registado = tb_ce_id_registado.Text,
                     asunto = tb_asunto.Text,
                     preco = tb_preco.Text,
                     descricao = tb_descricao.Text,
                     id_distrito = tb_id_distrito.Text,
                     id_concelho = tb_id_concelho.Text
                 }
                );

                client.Execute(request);
            }
        }
        
      
        private void btn_ver_users_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/user/" + tb_id.Text);
                var request = new RestRequest();
                request.Method = Method.GET;
                request.AddHeader("Accept", "application/json");
                request.AddHeader("ACCESS-TOKEN", LogToken.token);
                //request.Headers["X-My-Custom-Header"] = "the-value";
                var response = client.Execute(request);
                string content = response.Content; //raw content as string 

                Dictionary<string, string> resp = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);

                tb_username.Text = resp["username"];
                tb_auth_key.Text = resp["auth_key"];
                tb_password_hash.Text = resp["password_hash"];
                tb_password_reset_token.Text = resp["password_reset_token"];
                tb_email.Text = resp["email"];
                tb_status.Text = resp["status"];
                tb_created_at.Text = resp["created_at"];
                tb_updated_at.Text = resp["updated_at"];
                tb_primeiro_nome.Text = resp["primeiro_nome"];
                tb_ultimo_nome.Text = resp["ultimo_nome"];
                tb_contacto.Text = resp["contacto"];
            }
                
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/user/authenticate");
            var request = new RestRequest();
            request.Method = Method.POST;
            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddJsonBody(
             new
             {
                 username = tb_username_login.Text,
                 password = tb_password_login.Text
             }
            );


            var response = client.Execute(request);
            string content = response.Content; //raw content as string 

            LogToken = JsonConvert.DeserializeObject<Tok>(content);

            client.Execute(request);
        }

        private void btn_eliminar_users_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/user/" + tb_id.Text);
                var request = new RestRequest();
                request.Method = Method.DELETE;
                request.AddHeader("Accept", "application/json");
                request.AddHeader("ACCESS-TOKEN", LogToken.token);
                client.Execute(request);

                tb_id.Text = "";
                tb_auth_key.Text = "";
                tb_password_hash.Text = "";
                tb_email.Text = "";
                tb_status.Text = "";
                tb_created_at.Text = "";
                tb_updated_at.Text = "";
                tb_primeiro_nome.Text = "";
                tb_ultimo_nome.Text = "";
                tb_contacto.Text = "";
            }
        }

        private void btn_registar_Click(object sender, EventArgs e)
        {
            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/user");
            var request = new RestRequest();
            request.Method = Method.POST;
            request.AddHeader("Accept", "application/json");
            request.AddHeader("ACCESS-TOKEN", LogToken.token);
            request.Parameters.Clear();
            request.AddJsonBody(
             new
             {
                 username = tb_username_registar.Text,
                 email = tb_email_registar.Text,
                 password = tb_password_registar.Text
             }
            );

            client.Execute(request);
        }

        private void btn_alterar_users_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/user/" + tb_id.Text);
                var request = new RestRequest();
                request.Method = Method.PUT;
                request.AddHeader("Accept", "application/json");
                request.Parameters.Clear();
                request.AddJsonBody(
                 new
                 {
                     auth_key = tb_auth_key.Text,
                     password_hash = tb_password_hash.Text,
                     password_reset_token = tb_password_reset_token.Text,
                     email = tb_email.Text,
                     status = tb_status.Text,
                     created_at = tb_created_at.Text,
                     updated_at = tb_updated_at.Text,
                     primeiro_nome = tb_primeiro_nome.Text,
                     ultimo_nome = tb_ultimo_nome.Text,
                     contacto = tb_contacto.Text
                 }
                );

                client.Execute(request);
            }
        }

        private void btn_ver_distritos_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/distritos/" + tb_id_distritos.Text);
                var request = new RestRequest();
                request.Method = Method.GET;
                request.AddHeader("Accept", "application/json");
                var response = client.Execute(request);
                var content = response.Content; //raw content as string 

                Dictionary<string, string> resp = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);
                tb_id_distritos.Text = resp["id_distritos"];
                tb_nome_distritos.Text = resp["nome_distritos"];
            }
               
        }

        private void btn_eliminar_distritos_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/distritos/" + tb_id_distritos.Text);
                var request = new RestRequest();
                request.Method = Method.DELETE;
                request.AddHeader("Accept", "application/json");
                client.Execute(request);

                tb_id_distritos.Text = "";
                tb_nome_distritos.Text = "";
            }
        }

        private void btn_alterar_distritos_Click(object sender, EventArgs e)
        {
            if (tb_id_anuncio.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/distritos/" + tb_id_distritos.Text);
                var request = new RestRequest();
                request.Method = Method.PUT;
                request.AddHeader("Accept", "application/json");
                request.Parameters.Clear();
                request.AddJsonBody(
                 new
                 {
                     nome_distritos = tb_nome_distritos.Text
                 }
                );

                client.Execute(request);
            }
                
        }

        private void btn_adicionar_distritos_Click(object sender, EventArgs e)
        {
            if(tb_nome_distritos.Text != "")
            {
                var client = new RestClient("http://localhost/ProjWeb/api/web/v1/distritos");
                var request = new RestRequest();
                request.Method = Method.POST;
                request.AddHeader("Accept", "application/json");
                request.Parameters.Clear();
                request.AddJsonBody(
                 new
                 {
                     nome_distritos = tb_nome_distritos.Text
                 }
                );

                client.Execute(request);
            }
        }

        private void btn_todos_distritos_Click(object sender, EventArgs e)
        {
            this.lb_todos_distritos.Text = "";
            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/distritos");
            var request = new RestRequest();
            request.Method = Method.GET;
            request.AddHeader("Accept", "application/json");
            var response = client.Execute(request);
            var content = response.Content; //raw content as string 

            List<Dictionary<string, string>> resp = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(content);
            //var tb_id_distritos = resp["id_distritos"];
            //tb_nome_distritos.Text = resp["nome_distritos"];
            

            foreach (Dictionary<string, string> item in resp)
            {
                this.lb_todos_distritos.Items.Add(item["id_distritos"]);
                //this.lb_todos_distritos.Items.AddRange(item.Split("\n"));
                //this.lb_todos_distritos.Items.Add("Nome: " + item["nome_distritos"]);
                //this.lb_todos_distritos.Items.Add("");

                //this.lb_todos_distritos.Items.
            }
        }

        private void lb_todos_distritos_SelectedIndexChanged(object sender, EventArgs e)
        {
            string curItem = lb_todos_distritos.SelectedItem.ToString();
            
            // Find the string in ListBox2.
            int index = lb_todos_distritos.FindString(curItem);
            // If the item was not found in ListBox 2 display a message box, otherwise select it in ListBox2.

            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/distritos/" + curItem);
            var request = new RestRequest();
            request.Method = Method.GET;
            request.AddHeader("Accept", "application/json");
            var response = client.Execute(request);
            var content = response.Content; //raw content as string 

            Dictionary<string, string> resp = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);

            tb_id_distritos.Text = resp["id_distritos"];
            tb_nome_distritos.Text = resp["nome_distritos"];
        }

        private void btn_todos_anuncios_Click(object sender, EventArgs e)
        {
            this.lb_todos_distritos.Text = "";
            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/anuncio");
            var request = new RestRequest();
            request.Method = Method.GET;
            request.AddHeader("Accept", "application/json");
            var response = client.Execute(request);
            var content = response.Content; //raw content as string 

            List<Dictionary<string, string>> resp = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(content);
            //var tb_id_distritos = resp["id_distritos"];
            //tb_nome_distritos.Text = resp["nome_distritos"];


            foreach (Dictionary<string, string> item in resp)
            {
                this.lb_todos_anuncios.Items.Add(item["id_anuncio"]);
                //this.lb_todos_distritos.Items.AddRange(item.Split("\n"));
                //this.lb_todos_distritos.Items.Add("Nome: " + item["nome_distritos"]);
                //this.lb_todos_distritos.Items.Add("");

                //this.lb_todos_distritos.Items.
            }
        }

        private void btn_todos_users_Click(object sender, EventArgs e)
        {
            this.lb_todos_distritos.Text = "";
            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/user");
            var request = new RestRequest();
            request.Method = Method.GET;
            request.AddHeader("Accept", "application/json");
            request.AddHeader("ACCESS-TOKEN", LogToken.token);
            var response = client.Execute(request);
            var content = response.Content; //raw content as string 

            List<Dictionary<string, string>> resp = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(content);
            //var tb_id_distritos = resp["id_distritos"];
            //tb_nome_distritos.Text = resp["nome_distritos"];


            foreach (Dictionary<string, string> item in resp)
            {
                this.lb_todos_user.Items.Add(item["id"]);
                //this.lb_todos_distritos.Items.AddRange(item.Split("\n"));
                //this.lb_todos_distritos.Items.Add("Nome: " + item["nome_distritos"]);
                //this.lb_todos_distritos.Items.Add("");

                //this.lb_todos_distritos.Items.
            }
        }

        private void lb_todos_user_SelectedIndexChanged(object sender, EventArgs e)
        {
            string curItem = lb_todos_user.SelectedItem.ToString();

            // Find the string in ListBox2.
            int index = lb_todos_distritos.FindString(curItem);
            // If the item was not found in ListBox 2 display a message box, otherwise select it in ListBox2.

            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/user/" + curItem);
            var request = new RestRequest();
            request.Method = Method.GET;
            request.AddHeader("Accept", "application/json");
            request.AddHeader("ACCESS-TOKEN", LogToken.token);
            var response = client.Execute(request);
            var content = response.Content; //raw content as string 

            Dictionary<string, string> resp = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);

            tb_id.Text = resp["id"];
            tb_username.Text = resp["username"];
            tb_auth_key.Text = resp["auth_key"];
            tb_password_hash.Text = resp["password_hash"];
            tb_password_reset_token.Text = resp["password_reset_token"];
            tb_email.Text = resp["email"];
            tb_status.Text = resp["status"];
            tb_created_at.Text = resp["created_at"];
            tb_updated_at.Text = resp["updated_at"];
            tb_primeiro_nome.Text = resp["primeiro_nome"];
            tb_ultimo_nome.Text = resp["ultimo_nome"];
            tb_contacto.Text = resp["contacto"];
        }

        private void lb_todos_anuncios_SelectedIndexChanged(object sender, EventArgs e)
        {
            string curItem = lb_todos_anuncios.SelectedItem.ToString();

            // Find the string in ListBox2.
            int index = lb_todos_anuncios.FindString(curItem);
            // If the item was not found in ListBox 2 display a message box, otherwise select it in ListBox2.

            var client = new RestClient("http://localhost/ProjWeb/api/web/v1/anuncios/" + curItem);
            var request = new RestRequest();
            request.Method = Method.GET;
            request.AddHeader("Accept", "application/json");
            var response = client.Execute(request);
            var content = response.Content; //raw content as string 

            Dictionary<string, string> resp = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);

            tb_id_anuncio.Text = resp["id_anuncio"];
            tb_ce_id_registado.Text = resp["ce_id_user"];
            tb_asunto.Text = resp["asunto"];
            tb_preco.Text = resp["preco"];
            tb_descricao.Text = resp["descricao"];
            tb_id_distrito.Text = resp["id_distrito"];
            tb_id_concelho.Text = resp["id_concelho"];
        }
    }
}
