package pt.ipleira.estg.qwartus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ac_Qwartus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ac__qwartus);
    }
}
